
public class App {

    public static void main(String[] args) {
        StudentController sc = new StudentController();

        /**
         * ********* Initializing the TestHarness class *********
         */
        // TestHarness th = new TestHarness();
    }
}
