interface Fireable {
    public void firePerson();
}
